package chat;

import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class ClientHandler extends Thread {
    private Socket socket;
    private Server server;
    private BufferedReader reader;
    private PrintWriter writer;
    private String nickname;
    private int currentRoom;

    public ClientHandler(Socket socket, Server server) {
        this.socket = socket;
        this.server = server;
    }

    @Override
    public void run() {
        try {
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            writer = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);

            // 로그인 또는 회원가입 처리
            while (true) {
                String input = reader.readLine();
                System.out.println("클라이언트로부터 메시지 수신: " + input);
                if (input.startsWith("LOGIN ")) {
                    String[] parts = input.split(" ", 3);
                    if (parts.length == 3 && server.authenticateUser(parts[1], parts[2])) {
                        nickname = parts[1];
                        writer.println("LOGIN_SUCCESS");
                        break;
                    } else {
                        writer.println("LOGIN_FAIL");
                    }
                } else if (input.startsWith("REGISTER ")) {
                    String[] parts = input.split(" ", 3);
                    if (parts.length == 3 && server.registerUser(parts[1], parts[2])) {
                        writer.println("REGISTER_SUCCESS");
                    } else {
                        writer.println("REGISTER_FAIL");
                    }
                }
            }

            // 방 선택
            writer.println("방 번호를 입력하세요 (1-5):");
            String roomInput = reader.readLine();
            try {
                currentRoom = Integer.parseInt(roomInput);
                if (currentRoom < 1 || currentRoom > 5) {
                    currentRoom = 1;
                }
            } catch (NumberFormatException e) {
                currentRoom = 1;
            }

            server.addClientToRoom(this, currentRoom);
            server.broadcastToRoom(currentRoom, nickname + "님이 채팅방에 참여하셨습니다.");
            loadPreviousMessages();

            String message;
            while ((message = reader.readLine()) != null) {
                System.out.println("클라이언트로부터 메시지 수신: " + message);
                if (message.startsWith("CHAT ")) {
                    String chatMessage = message.substring(5);
                    System.out.println("욕설 필터링 전: " + chatMessage);
                    if (Server.containsProfanity(chatMessage)) {
                        System.out.println("욕설 감지: " + chatMessage);
                        chatMessage = Server.filterProfanity(chatMessage);
                        System.out.println("필터링 후: " + chatMessage);
                    }
                    String fullMessage = nickname + ": " + chatMessage;
                    server.broadcastToRoom(currentRoom, fullMessage);
                    server.handleReadReceipt(nickname, currentRoom, fullMessage.hashCode());
                } else if (message.startsWith("DRAW ")) {
                    server.handleDrawing(message.substring(5), this);
                } else if (message.startsWith("FILE ")) {
                    String[] parts = message.split(" ", 3);
                    if (parts.length == 3) {
                        String fileName = parts[1];
                        long fileSize = Long.parseLong(parts[2]);
                        server.handleFileTransfer(this, fileName, fileSize);
                    }
                } else if (message.startsWith("/room ")) {
                    try {
                        int newRoom = Integer.parseInt(message.substring(6));
                        changeRoom(newRoom);
                    } catch (NumberFormatException e) {
                        writer.println("잘못된 방 번호 형식입니다.");
                    }
                } else if (message.equals("LOGOUT")) {
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            server.removeClientFromRoom(this, currentRoom);
            server.broadcastToRoom(currentRoom, nickname + "님이 채팅방을 나갔습니다.");
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void changeRoom(int newRoom) {
        if (newRoom >= 1 && newRoom <= 5) {
            server.removeClientFromRoom(this, currentRoom);
            server.broadcastToRoom(currentRoom, nickname + "님이 방을 나갔습니다.");
            currentRoom = newRoom;
            server.addClientToRoom(this, currentRoom);
            server.broadcastToRoom(currentRoom, nickname + "님이 방에 들어왔습니다.");
            writer.println("방이 변경되었습니다. 현재 " + currentRoom + "번 방에 있습니다.");
            loadPreviousMessages();
        } else {
            writer.println("잘못된 방 번호입니다. 1-5 사이의 숫자를 입력해주세요.");
        }
    }

    private void loadPreviousMessages() {
        java.util.List<String> previousMessages = server.loadMessages(currentRoom);
        for (String msg : previousMessages) {
            sendMessage("CHAT " + msg);
        }
    }

    public void sendMessage(String message) {
        writer.println(message);
    }

    public void sendFile(File file) {
        try {
            writer.println("FILE " + file.getName() + " " + file.length());
            FileInputStream fis = new FileInputStream(file);
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                socket.getOutputStream().write(buffer, 0, bytesRead);
            }
            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Socket getSocket() {
        return socket;
    }

    public String getNickname() {
        return nickname;
    }

    public int getCurrentRoom() {
        return currentRoom;
    }
}