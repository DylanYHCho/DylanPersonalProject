package chat;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class ServerGui {
    private JFrame serverFrame;
    private JTextArea chatTextArea;
    protected JTextField chatTextField;
    private JList<String> userList;
    private JList<String> chatList;
    private DefaultListModel<String> userModel;
    private DefaultListModel<String> chatModel;
    
    public ServerGui() {
        serverFrame = new JFrame();
        serverFrame.setTitle("프렌드위드"); //타이틀명
        serverFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// 윈도우를 닫으면 프로그램 종료
        serverFrame.setBounds(100, 100, 825, 475);  //프레임 시작 위치(좌측 상단 모서리 기준)
        
        JPanel contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5)); //컨테이너의 테두리 여백 설정
        
        serverFrame.setContentPane(contentPane);
        contentPane.setLayout(null);
        
        //채팅 출력창
        chatTextArea = new JTextArea();
        chatTextArea.setEditable(false);
        JScrollPane chatScrollPane = new JScrollPane(chatTextArea);
        chatScrollPane.setBounds(20,20,550,350); //출력창 위치
        contentPane.add(chatScrollPane);
        
        //채팅 입력창
        chatTextField = new JTextField();
        chatTextField.setColumns(1000); //최대 입력길이 설정
        chatTextField.setBounds(20, 400, 550, 20); //입력창 위치
        contentPane.add(chatTextField);
        
        //유저 목록
        JLabel userListLabel = new JLabel("유저 목록");
        userListLabel.setBounds(600, 16, 100, 16);
        contentPane.add(userListLabel);
        
        userModel = new DefaultListModel<>();
        userList = new JList<>(userModel); //유저 목록 리스트
        JScrollPane userScrollPane = new JScrollPane(userList);
        userScrollPane.setBounds(600, 40, 200, 200);
        userScrollPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
        contentPane.add(userScrollPane);
        
        // 채팅 목록
        JLabel chatListLabel = new JLabel("채팅 목록");
        chatListLabel.setBounds(600, 260, 100, 16);
        contentPane.add(chatListLabel);

        chatModel = new DefaultListModel<>();
        chatList = new JList<>(chatModel);
        JScrollPane chatListScrollPane = new JScrollPane(chatList);
        chatListScrollPane.setBounds(600, 280, 200, 150);
        chatListScrollPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
        contentPane.add(chatListScrollPane);
    }

    public void setFrameVisible(){
        serverFrame.setVisible(true);
    }

    public void setTextFieldBlank(){
        chatTextField.setText(null);
    }

    public void appendMessage(String message){
        chatTextArea.append(message + "\n");
        chatTextArea.setCaretPosition(chatTextArea.getDocument().getLength());
        chatModel.addElement(message); // 채팅 목록에도 추가
        chatList.ensureIndexIsVisible(chatModel.size() - 1);
    }

    public void appendUserList(String user){
        userModel.addElement(user);
    }

    public void removeUserList(String user){
        userModel.removeElement(user);
    }

    public String getChatMessage(){ 
        return chatTextField.getText(); 
    }
}