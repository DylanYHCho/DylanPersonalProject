package chat;

import java.util.HashSet;
import java.util.Set;

public class Message {
    private String content;
    private Set<String> readBy;

    public Message(String content) {
        this.content = content;
        this.readBy = new HashSet<>();
    }

    public String getContent() {
        return content;
    }

    public void markAsRead(String username) {
        readBy.add(username);
    }

    public boolean isFullyRead(int totalClients) {
        return readBy.size() >= totalClients;
    }
}