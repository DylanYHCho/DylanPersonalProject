package chat;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class ClientGUI extends JFrame {
    private JTextArea chatArea;
    private JTextField messageField;
    private JButton sendButton;
    private DrawingPanel drawingPanel;
    private JButton loginButton;
    private JButton registerButton;
    private JButton logoutButton;
    private JButton sendFileButton;
    private JButton changeRoomButton;
    private JLabel currentRoomLabel;
    private PrintWriter out;
    private BufferedReader in;
    private Socket socket;
    private int currentRoom = 1;
    private JProgressBar fileProgressBar;

    public ClientGUI() {
        setTitle("프렌드위드");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
        addListeners();

        String serverIP = JOptionPane.showInputDialog(this, "서버 IP를 입력하세요:", "서버 연결", JOptionPane.QUESTION_MESSAGE);
        if (serverIP != null && !serverIP.isEmpty()) {
            connectToServer(serverIP);
            // PrintWriter를 DrawingPanel에 바로 설정
            drawingPanel.setOut(out);
        } else {
            JOptionPane.showMessageDialog(this, "유효한 IP 주소를 입력하세요.");
            System.exit(0);
        }
    }

    private void connectToServer(String serverIP) {
        try {
            System.out.println("서버 연결 시도: " + serverIP + ":8888");
            socket = new Socket(serverIP, 8888);
            System.out.println("서버 연결 성공");
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            new Thread(this::listenForMessages).start();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("서버 연결 실패: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "서버 연결 실패: " + e.getMessage());
            System.exit(0);
        }
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        
        // 채팅 영역과 그림판을 나란히 배치하기 위한 패널
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        
        // 채팅 영역 (오른쪽)
        JPanel chatPanel = new JPanel(new BorderLayout());
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatPanel.add(new JScrollPane(chatArea), BorderLayout.CENTER);
        
        // 메시지 입력 패널
        JPanel messagePanel = new JPanel(new BorderLayout());
        messageField = new JTextField();
        sendButton = new JButton("전송");
        messagePanel.add(messageField, BorderLayout.CENTER);
        messagePanel.add(sendButton, BorderLayout.EAST);
        chatPanel.add(messagePanel, BorderLayout.SOUTH);
        
        // 그림판 (왼쪽)
        drawingPanel = new DrawingPanel();
        
        // SplitPane에 추가
        splitPane.setLeftComponent(drawingPanel);
        splitPane.setRightComponent(chatPanel);
        splitPane.setResizeWeight(0.5);
        
        add(splitPane, BorderLayout.CENTER);
        
        // 상단 버튼 패널
        JPanel buttonPanel = new JPanel();
        loginButton = new JButton("로그인");
        registerButton = new JButton("회원가입");
        logoutButton = new JButton("로그아웃");
        sendFileButton = new JButton("파일 전송");
        changeRoomButton = new JButton("방 변경");
        currentRoomLabel = new JLabel("현재 방: 1");
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        buttonPanel.add(logoutButton);
        buttonPanel.add(sendFileButton);
        buttonPanel.add(changeRoomButton);
        buttonPanel.add(currentRoomLabel);
        add(buttonPanel, BorderLayout.NORTH);
        
        fileProgressBar = new JProgressBar(0, 100);
        fileProgressBar.setStringPainted(true);
        fileProgressBar.setVisible(false);
        add(fileProgressBar, BorderLayout.SOUTH);
    }

    private void addListeners() {
        sendButton.addActionListener(e -> {
            sendMessage();
            drawingPanel.setOut(out);
        });
        messageField.addActionListener(e -> sendMessage());
        loginButton.addActionListener(e -> showLoginDialog());
        registerButton.addActionListener(e -> showRegisterDialog());
        logoutButton.addActionListener(e -> logout());
        sendFileButton.addActionListener(e -> sendFile());
        changeRoomButton.addActionListener(e -> showChangeRoomDialog());
    }

    private void sendMessage() {
        String message = messageField.getText();
        if (!message.isEmpty()) {
            out.println("CHAT " + message);
            messageField.setText("");
        }
    }

    private void showLoginDialog() {
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        Object[] message = { "Username:", usernameField, "Password:", passwordField };
        int option = JOptionPane.showConfirmDialog(null, message, "Login", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            out.println("LOGIN " + username + " " + password);
        }
    }

    private void showRegisterDialog() {
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        Object[] message = { "Username:", usernameField, "Password:", passwordField };
        int option = JOptionPane.showConfirmDialog(null, message, "Register", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            out.println("REGISTER " + username + " " + password);
            System.out.println("서버에 회원가입 요청 전송: " + username);
        }
    }

    private void logout() {
        out.println("LOGOUT");
        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.exit(0);
    }

    private void sendFile() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                out.println("FILE " + selectedFile.getName() + " " + selectedFile.length());
                out.flush();
                FileInputStream fileInputStream = new FileInputStream(selectedFile);
                OutputStream outputStream = socket.getOutputStream();
                byte[] buffer = new byte[4096];
                int bytesRead;
                long totalBytesRead = 0;
                long fileSize = selectedFile.length();

                fileProgressBar.setVisible(true);
                fileProgressBar.setValue(0);

                while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                    totalBytesRead += bytesRead;
                    int progress = (int) ((totalBytesRead * 100) / fileSize);
                    SwingUtilities.invokeLater(() -> fileProgressBar.setValue(progress));
                }

                outputStream.flush();
                fileInputStream.close();
                fileProgressBar.setVisible(false);
                JOptionPane.showMessageDialog(this, "파일 전송이 완료되었습니다.");
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "파일 전송 중 오류가 발생했습니다.");
            }
        }
    }

    private void receiveFile(String fileName, long fileSize) {
        try {
            File receivedFile = new File("received_" + fileName);
            FileOutputStream fos = new FileOutputStream(receivedFile);
            byte[] buffer = new byte[4096];
            int bytesRead;
            long totalBytesRead = 0;

            SwingUtilities.invokeLater(() -> {
                fileProgressBar.setVisible(true);
                fileProgressBar.setValue(0);
                chatArea.append("파일 수신 시작: " + fileName + "\n");
            });

            while (totalBytesRead < fileSize && (bytesRead = socket.getInputStream().read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
                totalBytesRead += bytesRead;
                int progress = (int) ((totalBytesRead * 100) / fileSize);
                SwingUtilities.invokeLater(() -> fileProgressBar.setValue(progress));
            }

            fos.close();
            SwingUtilities.invokeLater(() -> {
                fileProgressBar.setVisible(false);
                chatArea.append("파일 수신 완료: " + fileName + "\n");
                int option = JOptionPane.showConfirmDialog(this,
                    "파일 수신 완료: " + fileName + "\n파일을 열어보시겠습니까?",
                    "파일 수신", JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.YES_OPTION) {
                    try {
                        Desktop.getDesktop().open(receivedFile);
                    } catch (IOException e) {
                        JOptionPane.showMessageDialog(this, "파일을 열 수 없습니다.");
                    }
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> {
                fileProgressBar.setVisible(false);
                JOptionPane.showMessageDialog(this, "파일 수신 중 오류 발생");
            });
        }
    }
    private void showChangeRoomDialog() {
        String input = JOptionPane.showInputDialog(this, "새로운 방 번호를 입력하세요 (1-5):");
        if (input != null && !input.isEmpty()) {
            try {
                int newRoom = Integer.parseInt(input);
                if (newRoom >= 1 && newRoom <= 5) {
                    out.println("/room " + newRoom);
                    currentRoom = newRoom;
                    currentRoomLabel.setText("현재 방: " + currentRoom);
                } else {
                    JOptionPane.showMessageDialog(this, "유효하지 않은 방 번호입니다. 1부터 5 사이의 숫자를 입력하세요.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "유효한 숫자를 입력하세요.");
            }
        }
    }

    private void listenForMessages() {
        try {
            String message;
            while ((message = in.readLine()) != null) {
                if (message.startsWith("CHAT ")) {
                    final String chatMessage = message.substring(5);
                    SwingUtilities.invokeLater(() -> {
                        chatArea.setForeground(Color.BLACK);
                        chatArea.append(chatMessage + "\n");
                        chatArea.setCaretPosition(chatArea.getDocument().getLength());
                    });
                } else if (message.startsWith("READ ")) {
                    String messageContent = message.substring(5);
                    SwingUtilities.invokeLater(() -> {
                        chatArea.setForeground(Color.GREEN);
                        chatArea.append(messageContent + "\n");
                        chatArea.setCaretPosition(chatArea.getDocument().getLength());
                    });
                } else if (message.startsWith("DRAW ")) {
                    final String drawingData = message.substring(5);
                    SwingUtilities.invokeLater(() -> drawingPanel.receiveDrawing(drawingData));
                } else if (message.startsWith("FILE ")) {
                    String[] parts = message.split(" ", 3);
                    if (parts.length == 3) {
                        String fileName = parts[1];
                        long fileSize = Long.parseLong(parts[2]);
                        receiveFile(fileName, fileSize);
                    }
                } else if (message.equals("LOGIN_SUCCESS")) {
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, "로그인 성공"));
                } else if (message.equals("LOGIN_FAIL")) {
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, "로그인 실패"));
                } else if (message.equals("REGISTER_SUCCESS")) {
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, "회원가입 성공"));
                } else if (message.equals("REGISTER_FAIL")) {
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, "회원가입 실패"));
                }
            }
        } catch (IOException e) {
            if (!socket.isClosed()) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "서버와의 연결이 끊어졌습니다.");
            }
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ClientGUI().setVisible(true));
    }
}