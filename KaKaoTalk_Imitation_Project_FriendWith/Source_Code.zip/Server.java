package chat;

import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*;
import java.awt.event.*;

public class Server {
    private ServerSocket serverSocket;
    private ServerGui serverGui;
    private Map<Integer, List<ClientHandler>> chatRooms = new HashMap<>();
    private Map<Integer, List<Message>> roomMessages = new HashMap<>();
    private static final Set<String> PROFANE_WORDS = new HashSet<>(Arrays.asList(
        "씨발", "개새끼", "병신", "ㅅㅂ", "ㅂㅅ", "꺼져", "ㅗ", "존나", "ㅈㄴ", "좆같네", "좆같다", "ㅈ같네"
    ));

    public static void main(String[] args) {
        new Server().start();
    }

    public Server() {
        for (int i = 1; i <= 5; i++) {
            chatRooms.put(i, new ArrayList<>());
            roomMessages.put(i, new ArrayList<>());
        }
    }

    public void start() {
        if (DatabaseConnection.testConnection()) {
            System.out.println("데이터베이스 연결 성공");
        } else {
            System.out.println("데이터베이스 연결 실패");
            return;
        }

        try (ServerSocket serverSocket = new ServerSocket(8888)) {
            this.serverSocket = serverSocket;
            serverGui = new ServerGui();
            serverGui.setFrameVisible();
            serverGui.appendMessage("서버가 8888 포트에서 시작되었습니다");

            serverGui.chatTextField.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                        String message = serverGui.getChatMessage().trim();
                        if (!message.isEmpty()) {
                            serverGui.appendMessage("서버: " + message);
                            broadcastToAllRooms("서버: " + message);
                        }
                        serverGui.setTextFieldBlank();
                    }
                }
            });

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("새로운 클라이언트 연결: " + clientSocket.getInetAddress());
                ClientHandler handler = new ClientHandler(clientSocket, this);
                handler.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void broadcastToAllRooms(String message) {
        for (List<ClientHandler> room : chatRooms.values()) {
            for (ClientHandler client : room) {
                client.sendMessage(message);
            }
        }
    }

    public void broadcastToRoom(int roomId, String message) {
        System.out.println("방 " + roomId + "에 메시지 브로드캐스트: " + message);
        List<ClientHandler> room = chatRooms.get(roomId);
        if (room != null) {
            for (ClientHandler client : room) {
            	client.sendMessage("CHAT " + message + " " + message.hashCode());
            }
        }
        roomMessages.get(roomId).add(new Message(message));
        saveMessage(roomId, message);
    }

    public void handleReadReceipt(String username, int roomId, int messageHash) {
        List<Message> messages = roomMessages.get(roomId);
        if (messages != null) {
            for (Message msg : messages) {
                if (msg.getContent().hashCode() == messageHash) {
                    msg.markAsRead(username);
                    if (msg.isFullyRead(chatRooms.get(roomId).size())) {
                        broadcastToRoom(roomId, "READ " + messageHash);
                    }
                    break;
                }
            }
        }
    }

    public void handleDrawing(String drawingData, ClientHandler sender) {
        int roomId = sender.getCurrentRoom();
        List<ClientHandler> room = chatRooms.get(roomId);
        if (room != null) {
            for (ClientHandler client : room) {
                if (client != sender) {  // 그림을 그린 클라이언트를 제외한 나머지 클라이언트에게 전송
                    client.sendMessage("DRAW " + drawingData);
                }
            }
        }
    }

    public void addClientToRoom(ClientHandler client, int roomId) {
        if (roomId < 1 || roomId > 5) {
            roomId = 1;
        }
        chatRooms.get(roomId).add(client);
        serverGui.appendUserList(client.getNickname() + " (방 " + roomId + ")");
        System.out.println("유저 " + client.getNickname() + " 방 " + roomId + "에 추가됨");
    }

    public void removeClientFromRoom(ClientHandler client, int roomId) {
        if (roomId < 1 || roomId > 5) {
            System.out.println("잘못된 방 번호: " + roomId);
            return;
        }
        List<ClientHandler> room = chatRooms.get(roomId);
        if (room != null) {
            room.remove(client);
            serverGui.removeUserList(client.getNickname() + " (방 " + roomId + ")");
            System.out.println("유저 " + client.getNickname() + " 방 " + roomId + "에서 제거됨");
        }
    }

    public boolean authenticateUser(String username, String password) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?")) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean registerUser(String username, String password) {
        System.out.println("회원가입 시도: " + username);
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO users (username, password) VALUES (?, ?)")) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean containsProfanity(String message) {
        for (String word : PROFANE_WORDS) {
            if (message.toLowerCase().contains(word)) {
                return true;
            }
        }
        return false;
    }

    public static String filterProfanity(String message) {
        for (String word : PROFANE_WORDS) {
            message = message.replaceAll(word, "*".repeat(word.length()));
        }
        return message;
    }

    public void handleFileTransfer(ClientHandler sender, String fileName, long fileSize) {
        try {
            File receivedFile = new File("received_" + fileName);
            FileOutputStream fos = new FileOutputStream(receivedFile);
            InputStream is = sender.getSocket().getInputStream();
            byte[] buffer = new byte[4096];
            int bytesRead;
            long totalBytesRead = 0;
            while (totalBytesRead < fileSize && (bytesRead = is.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
                totalBytesRead += bytesRead;
            }
            fos.close();
            for (ClientHandler client : chatRooms.get(sender.getCurrentRoom())) {
                if (client != sender) {
                    client.sendFile(receivedFile);
                }
            }
            serverGui.appendMessage(sender.getNickname() + "님이 파일을 전송했습니다: " + fileName);
            broadcastToRoom(sender.getCurrentRoom(), sender.getNickname() + "님이 파일을 공유했습니다: " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
            serverGui.appendMessage("파일 수신 중 오류 발생: " + e.getMessage());
        }
    }

    public void saveMessage(int roomId, String message) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT INTO messages (room_id, content) VALUES (?, ?)")) {
            pstmt.setInt(1, roomId);
            pstmt.setString(2, message);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<String> loadMessages(int roomId) {
        List<String> messages = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(
                     "SELECT content FROM messages WHERE room_id = ? ORDER BY timestamp")) {
            pstmt.setInt(1, roomId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                messages.add(rs.getString("content"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return messages;
    }
}