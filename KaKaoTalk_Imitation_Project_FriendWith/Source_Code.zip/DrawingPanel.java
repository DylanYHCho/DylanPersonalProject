package chat;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.io.PrintWriter;

public class DrawingPanel extends JPanel {
    private List<Point> points;
    private PrintWriter out;
    private boolean isDrawing;

    public DrawingPanel() {
        points = new ArrayList<>();
        setPreferredSize(new Dimension(400, 400));
        setBackground(Color.WHITE);
        
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                isDrawing = true;
                points.clear();
                points.add(e.getPoint());
                sendDrawingData();
                repaint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                isDrawing = false;
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (isDrawing) {
                    points.add(e.getPoint());
                    sendDrawingData();
                    repaint();
                }
            }
        });
    }

    public void setOut(PrintWriter out) {
        this.out = out;
    }

    private void sendDrawingData() {
        if (out != null) {
            StringBuilder data = new StringBuilder();
            for (Point p : points) {
                if (data.length() > 0) {
                    data.append(";");
                }
                data.append(p.x).append(",").append(p.y);
            }
            out.println("DRAW " + data.toString());
            out.flush();  // 데이터를 즉시 전송하도록 flush 추가
        }
    }

    public void receiveDrawing(String drawingData) {
        try {
            points.clear();
            if (drawingData != null && !drawingData.isEmpty()) {
                String[] pointStrings = drawingData.split(";");
                for (String pointString : pointStrings) {
                    String[] coordinates = pointString.split(",");
                    if (coordinates.length == 2) {
                        int x = Integer.parseInt(coordinates[0]);
                        int y = Integer.parseInt(coordinates[1]);
                        points.add(new Point(x, y));
                    }
                }
            }
            repaint();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(2));

        for (int i = 1; i < points.size(); i++) {
            Point p1 = points.get(i-1);
            Point p2 = points.get(i);
            g2.drawLine(p1.x, p1.y, p2.x, p2.y);
        }
    }
}